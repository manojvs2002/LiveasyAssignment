package com.Springrest.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Springrest.springrest.entities.Loads;
import com.Springrest.springrest.services.LoadService;

@RestController
public class MyController {
	
	
	@Autowired
	private LoadService loadservice;
	
	@GetMapping("/home")
	public String home() {
		return "Welcome to my internship project";
	}

	//get the items
	@GetMapping("/load")
	public List<Loads> getLoads(){
		return this.loadservice.getLoads() ;
		}
	 @GetMapping("/load/{shipperid}")
	public Loads getLoad(@PathVariable int shipperid) {
		return this.loadservice.getLoad(shipperid);
	}
	 
	 @PostMapping("/load")
	 public Loads addLoads(@RequestBody Loads load) {
		 
		 return this.loadservice.addLoads(load);
	}
	 
	 @PutMapping("/load")
	 public Loads updateLoads(@RequestBody Loads load) {
		 return this.loadservice.updateLoads(load);
	 }
	 
	 @DeleteMapping("/load/{loadid}")
	 public ResponseEntity<HttpStatus> deleteLoad(@PathVariable String loadid){
		 try {
			 this.loadservice.deleteLoad(Long.parseLong(loadid));
			 return new ResponseEntity<>(HttpStatus.OK);
		 }
		 catch(Exception e){
			 return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		 }
	 }
	 
}
