package com.Springrest.springrest.doa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Springrest.springrest.entities.Loads;

public interface LoadDoa extends JpaRepository<Loads, Long> {

	
}
