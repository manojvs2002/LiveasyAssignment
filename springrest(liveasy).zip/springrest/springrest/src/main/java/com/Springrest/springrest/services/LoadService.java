package com.Springrest.springrest.services;

import java.util.List;

import com.Springrest.springrest.entities.Loads;

public interface LoadService {

	public List<Loads> getLoads();

	public Loads getLoad(int shipperid);

	public Loads addLoads(Loads load);

	public Loads updateLoads(Loads load);

	public void deleteLoad(long parseLong);
}


	
