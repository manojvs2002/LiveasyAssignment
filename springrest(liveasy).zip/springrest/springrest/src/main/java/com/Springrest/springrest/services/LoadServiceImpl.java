package com.Springrest.springrest.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Springrest.springrest.doa.LoadDoa;
import com.Springrest.springrest.entities.Loads;

@Service
public class LoadServiceImpl implements LoadService {

	@Autowired
	private LoadDoa loadDoa;
	
//	List<Loads> list;
	
	public LoadServiceImpl() {
		
//		list=new ArrayList<>();
//		list.add(new Loads("canter",1,"chemicals","delhi","jaipur",100,984562,"09/06/2002"));
//		
	}
//	"loadingPoint": "delhi",
//	"unloadingPoint": "jaipur",
//	"productType": "chemicals",
//	"truckType": "canter",
//	"noOfTrucks": "1",
//	"weight": "100",
//	optional:"comment": "",
//	“shipperId” : “shipper:<UUID>”,
//	“Date” : “dd-mm-yyyy”
	
	@Override
	public List<Loads> getLoads() {
	
		return loadDoa.findAll();
	}

	@Override
	public Loads getLoad(int shipperid) {
		
//		Loads l=null;
//		
//		for(Loads load:list) {
//			if(load.getShipperid()==shipperid) {
//				l=load;
//				break;
//			}
//		}
		return loadDoa.getOne((long) shipperid);
	}

	@Override
	public Loads addLoads(Loads load) {
//		list.add(load);
		loadDoa.save(load);
		return load;
	}

	@Override
	public Loads updateLoads(Loads load) {
		
//		list.forEach(e -> {
//			if(e.getShipperid()==load.getShipperid()) {
//				e.setDate(load.getDate());
//				e.setLoadingpoint(load.getLoadingpoint());
//				e.setUnloadingPoint(load.getUnloadingPoint());
//				e.setNoOfTrucks(load.getNoOfTrucks());
//				e.setProductType(load.getProductType());
//				e.setTructType(load.getTructType());
//				e.setWeight(load.getWeight());
//			}
//		});
		
		loadDoa.save(load);
		
		return load;
	}

	@Override
	public void deleteLoad(long parseLong) {
//		list=this.list.stream().filter(e->e.getShipperid()!=parseLong).collect(Collectors.toList());
		Loads entity=loadDoa.getOne(parseLong);
		loadDoa.delete(entity);
		
		
	}

	


}
