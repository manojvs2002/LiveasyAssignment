package com.Springrest.springrest.entities;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Loads {
	
//	"loadingPoint": "delhi",
//	"unloadingPoint": "jaipur",
//	"productType": "chemicals",
//	"truckType": "canter",
//	"noOfTrucks": "1",
//	"weight": "100",
//	optional:"comment": "",
//	“shipperId” : “shipper:<UUID>”,
//	“Date” : “dd-mm-yyyy”
	
	@Id
	private String tructType;
	private int noOfTrucks;
	private String productType;
	private String loadingpoint;
	private String unloadingPoint;
	private int weight;
	private int shipperid;
	private Date date;
	
	
	@Override
	public String toString() {
		return "Loads [tructType=" + tructType + ", noOfTrucks=" + noOfTrucks + ", productType=" + productType
				+ ", loadingpoint=" + loadingpoint + ", unloadingPoint=" + unloadingPoint + ", weight=" + weight
				+ ", shipperid=" + shipperid + ", date=" + date + "]";
	}
	public String getTructType() {
		return tructType;
	}
	public void setTructType(String tructType) {
		this.tructType = tructType;
	}
	public int getNoOfTrucks() {
		return noOfTrucks;
	}
	public void setNoOfTrucks(int noOfTrucks) {
		this.noOfTrucks = noOfTrucks;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getLoadingpoint() {
		return loadingpoint;
	}
	public void setLoadingpoint(String loadingpoint) {
		this.loadingpoint = loadingpoint;
	}
	public String getUnloadingPoint() {
		return unloadingPoint;
	}
	public void setUnloadingPoint(String unloadingPoint) {
		this.unloadingPoint = unloadingPoint;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public int getShipperid() {
		return shipperid;
	}
	public void setShipperid(int shipperid) {
		this.shipperid = shipperid;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Loads() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Loads(String tructType, int noOfTrucks, String productType, String loadingpoint, String unloadingPoint,
			int weight, int shipperid, String date) {
		super();
		this.tructType = tructType;
		this.noOfTrucks = noOfTrucks;
		this.productType = productType;
		this.loadingpoint = loadingpoint;
		this.unloadingPoint = unloadingPoint;
		this.weight = weight;
		this.shipperid = shipperid;
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	    try {
	        this.date = dateFormat.parse(date);
	    } catch (ParseException e) {
	        // Handle the parse exception if needed
	        e.printStackTrace();
	    }
	}

}
